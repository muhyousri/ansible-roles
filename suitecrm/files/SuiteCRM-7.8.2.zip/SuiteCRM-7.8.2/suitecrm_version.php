<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.8.2';
$suitecrm_timestamp    = '2017-02-27 17:00';